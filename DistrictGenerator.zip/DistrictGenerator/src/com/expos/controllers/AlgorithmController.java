package com.expos.controllers;


import com.expos.models.DistrictsEntity;
import com.expos.models.StatesEntity;
import com.expos.objects.District;
import com.expos.objects.State;
import com.expos.services.AlgorithmService;
import com.expos.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;

@Controller
public class AlgorithmController {
    
    ModelAndView mv;

    private AlgorithmService algorithmService;

    private StatesEntity currentState;

    @Autowired
    public void setUserService(AlgorithmService algorithmService) {
        this.algorithmService = algorithmService;
    }

    @RequestMapping(value = "/algorithm")
    @ResponseBody
    public ModelAndView runAlgorithm(@RequestParam Map<String, String> allRequestParam) {
        mv = new ModelAndView("index");
        String state = allRequestParam.get("state");
        int year = Integer.parseInt(allRequestParam.get("year"));
        float compactness = Float.parseFloat(allRequestParam.get("compactness"));
        boolean contiguity = Boolean.parseBoolean(allRequestParam.get("contiguity"));
        float populationEquality = Float.parseFloat(allRequestParam.get("populationEquality"));
        float partisanFairness = Float.parseFloat(allRequestParam.get("partisanFairness"));
        float racialFairness = Float.parseFloat(allRequestParam.get("racialFairness"));
        boolean preservation = Boolean.parseBoolean(allRequestParam.get("preservation"));
        StatesEntity statesEntity = algorithmService.getState(state, year);
        List<DistrictsEntity> districtsEntities = algorithmService.getDistricts(state, year);
        List<District> districts = algorithmService.convertToDistricts(districtsEntities);
        State currentState = algorithmService.convertToState(statesEntity);
        currentState.setDistricts(districts);
        return mv;
    }


}
