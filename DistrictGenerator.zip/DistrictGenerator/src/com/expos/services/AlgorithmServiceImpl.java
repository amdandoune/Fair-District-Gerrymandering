package com.expos.services;

import com.expos.dao.StateDao;
import com.expos.models.DistrictsEntity;
import com.expos.models.PrecinctsEntity;
import com.expos.models.StatesEntity;
import com.expos.models.StatesEntityPK;
import com.expos.objects.District;
import com.expos.objects.State;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class AlgorithmServiceImpl implements AlgorithmService {
    ModelAndView mv;
    @Autowired
    StateDao stateDao;

    @Transactional
    public StatesEntity getState(String stateName, int year) {
        StatesEntityPK stateKey = new StatesEntityPK();
        stateKey.setStateName(stateName);
        stateKey.setYear(year);
        return stateDao.get(stateKey);
    }

    @Transactional
    public List<DistrictsEntity> getDistricts(String stateName, int year) {
        List list = null;
        return list;
    }

    @Transactional
    public List<District> loadDistrictsPrecincts(List<District> districts) {
        District district = districts.get(0);
        String stateName = district.getStateName();
        int year = district.getYear();
        List<PrecinctsEntity> precintsList = getPrecincts(stateName, year);
        for (District dist : districts) {
            String districtName = dist.getDistrictName();
            for (PrecinctsEntity precinct : precintsList) {
                if (precinct.getDistrictName() == districtName) {
                    dist.addToPrecincts(precinct);
                }
            }
        }
        return districts;
    }

    @Transactional
    public List<PrecinctsEntity> getPrecincts(String stateName, int year) {
        List list = null;
        return list;
    }

    @Transactional
    public State convertToState(StatesEntity statesEntity) {
        State state = new State();
        state.setStateName(statesEntity.getStateName());
        state.setYear(statesEntity.getYear());
        state.setPopulation(statesEntity.getPopulation());
        return state;
    }

    @Transactional
    public List<District> convertToDistricts(List<DistrictsEntity> districtEntityList) {
        List<District> list = null;
        for (DistrictsEntity districtEntity : districtEntityList) {
            District district = new District();
            district.setStateName(districtEntity.getStateName());
            district.setYear(districtEntity.getYear());
            district.setDistrictName(districtEntity.getDistrictName());
            district.setPopulation(districtEntity.getPopulation());
            district.setRepublicans(districtEntity.getRepublicans());
            district.setDemocrats(districtEntity.getDemocrats());
            district.setOther(districtEntity.getOther());
            list.add(district);
        }
        return list;
    }

}
