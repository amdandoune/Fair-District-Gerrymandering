package com.expos.services;

import com.expos.models.DistrictsEntity;
import com.expos.models.PrecinctsEntity;
import com.expos.models.StatesEntity;
import com.expos.objects.District;
import com.expos.objects.State;

import java.util.List;

public interface AlgorithmService {

    StatesEntity getState(String stateName, int year);

    List<DistrictsEntity> getDistricts(String stateName, int year);

    List<PrecinctsEntity> getPrecincts(String stateName, int year);

    List<District> loadDistrictsPrecincts(List<District> districts);


    State convertToState(StatesEntity statesEntity);

    List<District> convertToDistricts(List<DistrictsEntity> districtsEntities);

}
