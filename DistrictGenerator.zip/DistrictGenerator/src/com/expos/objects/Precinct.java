package com.expos.objects;

public class Precinct {
    
}
