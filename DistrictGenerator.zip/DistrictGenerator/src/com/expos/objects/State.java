package com.expos.objects;

import java.util.List;

public class State {
    private String stateName;
    private int year;
    private int population;

    private float compactness;
    private float equalPopulation;
    private float racialFairness;
    private Boolean contiguity;
    private Boolean preservation;

    private List<District> districts;


    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public float getCompactness() {
        return compactness;
    }

    public void setCompactness(float compactness) {
        this.compactness = compactness;
    }

    public float getEqualPopulation() {
        return equalPopulation;
    }

    public void setEqualPopulation(float equalPopulation) {
        this.equalPopulation = equalPopulation;
    }

    public float getRacialFairness() {
        return racialFairness;
    }

    public void setRacialFairness(float racialFairness) {
        this.racialFairness = racialFairness;
    }

    public Boolean getContiguity() {
        return contiguity;
    }

    public void setContiguity(Boolean contiguity) {
        this.contiguity = contiguity;
    }

    public Boolean getPreservation() {
        return preservation;
    }

    public void setPreservation(Boolean preservation) {
        this.preservation = preservation;
    }

    public List<District> getDistricts() {
        return districts;
    }

    public void setDistricts(List<District> districts) {
        this.districts = districts;
    }

    public void addToDistricts(District district) {
        this.districts.add(district);
    }


}
