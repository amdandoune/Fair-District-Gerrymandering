package com.expos.objects;

import com.expos.models.PrecinctsEntity;

import java.util.List;

public class District {
    private String districtName;
    private String stateName;
    private int year;
    private int population;
    private int republicans;
    private int democrats;
    private int other;

    private List<PrecinctsEntity> precincts;
    private List<PrecinctsEntity> borderPrecincts;


    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public int getRepublicans() {
        return republicans;
    }

    public void setRepublicans(int republicans) {
        this.republicans = republicans;
    }

    public int getDemocrats() {
        return democrats;
    }

    public void setDemocrats(int democrats) {
        this.democrats = democrats;
    }

    public int getOther() {
        return other;
    }

    public void setOther(int other) {
        this.other = other;
    }

    public List<PrecinctsEntity> getPrecincts() {
        return precincts;
    }

    public void setPrecincts(List<PrecinctsEntity> precincts) {
        this.precincts = precincts;
    }

    public List<PrecinctsEntity> getBorderPrecincts() {
        return borderPrecincts;
    }

    public void setBorderPrecincts(List<PrecinctsEntity> borderPrecincts) {
        this.borderPrecincts = borderPrecincts;
    }

    public void addToPrecincts(PrecinctsEntity precinct) {
        this.precincts.add(precinct);
    }
    

    public void addToBorderPrecincts(PrecinctsEntity precinct) {
        this.borderPrecincts.add(precinct);
    }


}
