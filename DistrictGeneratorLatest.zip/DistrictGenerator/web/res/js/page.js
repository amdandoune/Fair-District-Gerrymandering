function getCompactnessWeight() {
    var sliderValue = document.getElementById('compactness').value;
    document.getElementById('CompactnessWeight').innerHTML = sliderValue;
    document.getElementById('CompactnessWeightInput').value = sliderValue;
}

function getPartisanFairnessWeight() {
    var sliderValue1 = document.getElementById('partisan-fairness').value;
    document.getElementById('PartisanFairnessWeight').innerHTML = sliderValue1;
    document.getElementById('PartisanFairnessWeightInput').value = sliderValue1;
}

function getRacialFairnessWeight() {
    var sliderValue2 = document.getElementById('racial-fairness').value;
    document.getElementById('RacialFairnessWeight').innerHTML = sliderValue2;
    document.getElementById('RacialFairnessWeightInput').value = sliderValue2;
}

function getEqualPopulationWeight() {
    var sliderValue3 = document.getElementById('equal-population').value;
    document.getElementById('EqualPopulationWeight').innerHTML = sliderValue3;
    document.getElementById('EqualPopulationWeightInput').value = sliderValue3;
}


function getCompactnessChioce() {
    var compactnessChioce = document.getElementById('compactness-radio').value;
    var compactness_value;
    if (document.getElementById('chioce1').checked) {
        compactness_value = document.getElementById('chioce1').value;
    }
    else if (document.getElementById('chioce2').checked) {
        compactness_value = document.getElementById('chioce2').value;
    }
    else if (document.getElementById('chioce3').checked) {
        compactness_value = document.getElementById('chioce3').value;
    }
    else if (document.getElementById('chioce4').checked) {
        compactness_value = document.getElementById('chioce4').value;
    }
    document.getElementById('CompactnessChioceValue').innerHTML = compactness_value;
    document.getElementById('CompactnessChioceValueInput').value = compactness_value;
}


function getPartisanFairnessChioce() {
    var getPartisanFairnessChioce = document.getElementById('partisan-fairness-radio').value;
    var getPartisanFairness_value;
    if (document.getElementById('chioce1-1').checked) {
        getPartisanFairness_value = document.getElementById('chioce1-1').value;
    } else if (document.getElementById('chioce2-1').checked) {
        getPartisanFairness_value = document.getElementById('chioce2-1').value;
    } else if (document.getElementById('chioce3-1').checked) {
        getPartisanFairness_value = document.getElementById('chioce3-1').value;
    }
    document.getElementById('PartisanFairnessChioceValue').innerHTML = getPartisanFairness_value;
    document.getElementById('PartisanFairnessChioceValueInput').value = getPartisanFairness_value;
}


function getContiguitiyCheckBox() {
    var ContiguitiyValue;

    if (document.getElementById('Contiguitiy').checked) {
        ContiguitiyValue = 1;
    } else {
        ContiguitiyValue = 0;
    }
    document.getElementById('ContiguitiyValue').innerHTML = ContiguitiyValue;
}

function getConnservationCheckBox() {
    var ConservationValue;

    if (document.getElementById('Conservation').checked) {
        ConservationValue = 1;
    } else {
        ConservationValue = 0;
    }
    document.getElementById('ConservationValue').innerHTML = ConservationValue;
}
