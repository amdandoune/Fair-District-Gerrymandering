package com.expos.dao;

import com.expos.models.PrecinctpositionsEntity;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrecinctPositionsDaoImpl implements PrecinctPositionDao {

    @Autowired
    private SessionFactory sessionFactory;

    public List<PrecinctpositionsEntity> list(String stateName, String precinctName) {
        Session session = sessionFactory.openSession();
        List<PrecinctpositionsEntity> list = null;
        try {
            session = sessionFactory.openSession();
            String sql = "SELECT * FROM expos.precinctpositions WHERE stateName = (:stateName) AND precinctName = (:precinctName)";
            SQLQuery query = session.createSQLQuery(sql);
            query.addEntity(PrecinctpositionsEntity.class);
            query.setParameter("stateName", stateName);
            query.setParameter("precinctName", precinctName);
            list = query.list();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
