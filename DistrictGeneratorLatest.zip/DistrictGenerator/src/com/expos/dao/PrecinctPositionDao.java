package com.expos.dao;

import com.expos.models.PrecinctpositionsEntity;

import java.util.List;

public interface PrecinctPositionDao {

    List<PrecinctpositionsEntity> list(String stateName, String precinctName);

}
