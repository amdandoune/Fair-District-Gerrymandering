package com.expos.dao;


import com.expos.models.PolygonsEntity;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TestDao {


    @Autowired
    private SessionFactory sessionFactory;

    public List<PolygonsEntity> getPolygon() {
        Session session = null;
        byte[] polygon = null;
        List<PolygonsEntity> list = new ArrayList();
        try {
            session = sessionFactory.openSession();
            String sql = "SELECT * FROM expos.polygons";
            SQLQuery query = session.createSQLQuery(sql);
            query.addEntity(PolygonsEntity.class);
            list = query.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


}
