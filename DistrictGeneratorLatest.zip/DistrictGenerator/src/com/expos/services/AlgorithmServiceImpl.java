package com.expos.services;

import com.expos.dao.*;
import com.expos.models.*;
import com.expos.objects.District;
import com.expos.objects.Precinct;
import com.expos.objects.State;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import javax.transaction.Transactional;
import java.util.*;

@Service
public class AlgorithmServiceImpl implements AlgorithmService {
    ModelAndView mv;
    @Autowired
    StateDao stateDao;

    @Autowired
    DistrictDao districtDao;

    @Autowired
    PrecinctDao precinctDao;

    @Autowired
    PrecinctPositionDao precinctPositionDao;

    @Autowired
    TestDao testDao;

    @Transactional
    public StatesEntity getStateEntity(String stateName, int year) {
        StatesEntityPK stateKey = new StatesEntityPK();
        stateKey.setStateName(stateName);
        stateKey.setYear(year);
        return stateDao.get(stateKey);
    }

    @Transactional
    public State getState(String stateName, int year) {
        StatesEntity statesEntity = getStateEntity(stateName, year);
        State state = new State(statesEntity);
        return state;
    }

    @Transactional
    public List<DistrictsEntity> getDistrictEntities(String stateName, int year) {
        List list = districtDao.list(stateName, year);
        return list;
    }

    @Transactional
    public List<District> getDistricts(String stateName, int year) {
        List<DistrictsEntity> districtEntityList = getDistrictEntities(stateName, year);
        List<District> list = new ArrayList<District>();
        for (DistrictsEntity districtEntity : districtEntityList) {
            District district = new District(districtEntity);
            district.setPrecincts(getPrecincts(districtEntity.getStateName(), districtEntity.getYear(), districtEntity.getDistrictName()));
            list.add(district);
        }
        return list;
    }

    @Transactional
    public List<PrecinctsEntity> getPrecinctEntities(String stateName, int year, String districtName) {
        List list = precinctDao.list(stateName, year, districtName);
        return list;
    }

    @Transactional
    public List<Precinct> getPrecincts(String stateName, int year, String districtName) {
        List<PrecinctsEntity> precinctsEntityList = getPrecinctEntities(stateName, year, districtName);
        List<Precinct> list = new ArrayList<Precinct>();
        for (PrecinctsEntity precinctsEntity : precinctsEntityList) {
            Precinct precinct = new Precinct(precinctsEntity);
            list.add(precinct);
        }
        return list;
    }

    @Transactional
    public List<PrecinctpositionsEntity> getPrecinctPositions(String stateName, String precinctName) {
        List<PrecinctpositionsEntity> list = precinctPositionDao.list(stateName, precinctName);
        return list;
    }

    public List<PolygonsEntity> test() {
        return testDao.getPolygon();
    }

    public void calculateObjectiveFunctions(State state) {
        for (District district : state.getDistricts()) {
            calculateObjectiveFunctions(district);
        }
    }

    public void calculateObjectiveFunctions(District district) {
        district.setCompactness(calculateCompactness(district));
        district.setEqualPopulation(calculateEqualPopulation(district));
        district.setRacialFairness(calculateRacialFairness(district));
        district.setPartisanFairness(calculatePartisanFairness(district));
        district.setContiguity(calculateContiguity(district));
        district.setPreservation(calculatePreservation(district));
    }

    public float calculateCompactness(District district) {


        return 0;
    }

    public float calculateEqualPopulation(District district) {
        return 0;
    }

    public float calculateRacialFairness(District district) {
        return 0;
    }

    public float calculatePartisanFairness(District district) {
        return 0;
    }

    public boolean calculateContiguity(District district) {
        return false;
    }

    public boolean calculatePreservation(District district) {
        return false;
    }

    public State getBetterState(State oldState, State newState, HashMap<String, Integer> weights) {
        float weightedCompactnessDiff = (newState.getCompactness() - oldState.getCompactness()) * weights.get("compactness");
        float weightedEqualPopulationDiff = (newState.getEqualPopulation() - oldState.getEqualPopulation()) * weights.get("equalPopulation");
        float weightedRacialFairnessDiff = (newState.getRacialFairness() - oldState.getRacialFairness()) * weights.get("racialFairness");
        float weightedPartisanFairnessDiff = (newState.getPartisanFairness() - oldState.getPartisanFairness()) * weights.get("partisanFairness");
        float weightedSum = weightedCompactnessDiff + weightedEqualPopulationDiff + weightedPartisanFairnessDiff + weightedRacialFairnessDiff;
        int contiguityWeight = weights.get("contiguity");
        int preservationWeight = weights.get("preservation");

        int newStateMeasure = 0;
        int oldStateMeasure = 0;
        if (newState.isContiguity())
            newStateMeasure += (contiguityWeight);
        if (newState.isPreservation())
            newStateMeasure += (preservationWeight);
        if (oldState.isContiguity())
            oldStateMeasure += (contiguityWeight);
        if (oldState.isPreservation())
            oldStateMeasure += (preservationWeight);
        if (newStateMeasure > oldStateMeasure)
            return newState;
        else if (newStateMeasure < oldStateMeasure)
            return oldState;
        else if (weightedSum >= 0)
            return newState;
        else
            return oldState;
    }
}

