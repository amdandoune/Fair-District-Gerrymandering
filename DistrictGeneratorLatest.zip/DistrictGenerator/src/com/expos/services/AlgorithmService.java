package com.expos.services;

import com.expos.models.DistrictsEntity;
import com.expos.models.PolygonsEntity;
import com.expos.models.PrecinctsEntity;
import com.expos.models.StatesEntity;
import com.expos.objects.District;
import com.expos.objects.Precinct;
import com.expos.objects.State;

import java.util.HashMap;
import java.util.List;

public interface AlgorithmService {

    StatesEntity getStateEntity(String stateName, int year);

    State getState(String stateName, int year);

    List<DistrictsEntity> getDistrictEntities(String stateName, int year);

    List<District> getDistricts(String stateName, int year);

    List<PrecinctsEntity> getPrecinctEntities(String stateName, int year, String districtName);

    List<Precinct> getPrecincts(String stateName, int year, String districtName);

    List<PolygonsEntity> test();

    public void calculateObjectiveFunctions(State state);

    void calculateObjectiveFunctions(District district);

    float calculateCompactness(District district);

    float calculateEqualPopulation(District district);

    float calculateRacialFairness(District district);

    float calculatePartisanFairness(District district);

    boolean calculateContiguity(District district);

    boolean calculatePreservation(District district);

    State getBetterState(State oldState, State newState, HashMap<String, Integer> weights);

}
