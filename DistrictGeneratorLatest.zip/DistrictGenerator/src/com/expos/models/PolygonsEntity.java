package com.expos.models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "polygons", schema = "expos", catalog = "")
public class PolygonsEntity {
    private int id;
    private byte[] polygon;

    @Id
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "polygon")
    public byte[] getPolygon() {
        return polygon;
    }

    public void setPolygon(byte[] polygon) {
        this.polygon = polygon;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PolygonsEntity that = (PolygonsEntity) o;
        return id == that.id &&
                Objects.equals(polygon, that.polygon);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, polygon);
    }
}
