package com.expos.models;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "precinctpositions", schema = "expos", catalog = "")
@IdClass(PrecinctpositionsEntityPK.class)
public class PrecinctpositionsEntity {
    private String precinctName;
    private double longitude;
    private double latitude;
    private String stateName;

    @Id
    @Column(name = "precinctName")
    public String getPrecinctName() {
        return precinctName;
    }

    public void setPrecinctName(String precinctName) {
        this.precinctName = precinctName;
    }

    @Id
    @Column(name = "longitude")
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    @Id
    @Column(name = "latitude")
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    @Id
    @Column(name = "stateName")
    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PrecinctpositionsEntity that = (PrecinctpositionsEntity) o;
        return Double.compare(that.longitude, longitude) == 0 &&
                Double.compare(that.latitude, latitude) == 0 &&
                Objects.equals(precinctName, that.precinctName) &&
                Objects.equals(stateName, that.stateName);
    }

    @Override
    public int hashCode() {

        return Objects.hash(precinctName, longitude, latitude, stateName);
    }
}
