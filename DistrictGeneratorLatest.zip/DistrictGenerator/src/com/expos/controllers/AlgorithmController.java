package com.expos.controllers;

import com.expos.models.*;
import com.expos.objects.District;
import com.expos.objects.Precinct;
import com.expos.objects.State;
import com.expos.services.AlgorithmService;
import com.expos.services.UserService;
import javafx.beans.binding.IntegerBinding;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.awt.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AlgorithmController {

    ModelAndView mv;

    private AlgorithmService algorithmService;

    @Autowired
    public void setUserService(AlgorithmService algorithmService) {
        this.algorithmService = algorithmService;
    }

    @RequestMapping(value = "/algorithm")
    @ResponseBody
    public ModelAndView runAlgorithm(@RequestParam Map<String, String> allRequestParam) {
        mv = new ModelAndView("index");


        String state = allRequestParam.get("state");
        String year = allRequestParam.get("year");
        System.out.println(state + " " + year);

        System.out.println("Compactness = " + allRequestParam.get("compactness"));
        System.out.println("PartisanFairness = " + allRequestParam.get("partisanFairness"));
        System.out.println("RacialFairness = " + allRequestParam.get("racialFairness"));
        System.out.println("EqualPopulation = " + allRequestParam.get("equalPopulation"));

        System.out.println("CompactnessAlgo = " + allRequestParam.get("compactnessAlgo"));
        System.out.println("PartisanFairnessAlgo = " + allRequestParam.get("partisanFairnessAlgo"));

        if (allRequestParam.get("contiguity") != null) {
            System.out.println("Contiguity = " + 1);
        }

        if (allRequestParam.get("preservation") != null) {
            System.out.println("Preservation = " + 1);
        }


//        HashMap<String, Integer> weights = new HashMap<String, Integer>();
//        weights.put("compactness", Integer.parseInt(allRequestParam.get("compactness")));
//        weights.put("contiguity", Integer.parseInt(allRequestParam.get("contiguity")));
//        weights.put("equalPopulation", Integer.parseInt(allRequestParam.get("equalPopulation")));
//        weights.put("preservation", Integer.parseInt(allRequestParam.get("preservation")));
//        weights.put("partisanFairness", Integer.parseInt(allRequestParam.get("partisanFairness")));
//        weights.put("racialFairness", Integer.parseInt(allRequestParam.get("racialFairness")));
//
//        State oldState = algorithmService.getState(allRequestParam.get("state"), Integer.parseInt(allRequestParam.get("year")));
//        List<District> districts = algorithmService.getDistricts(allRequestParam.get("state"), Integer.parseInt(allRequestParam.get("year")));
//        oldState.setDistricts(districts);
//        oldState.processDistrictBorders();
//        algorithmService.calculateObjectiveFunctions(oldState);
//        oldState.setObjectiveMeasures();
//
//        State newState = new State(oldState);
//
//        District randomDistrict = newState.getRandomDistrict();
//        District workingDistrict = null;
//        while (workingDistrict.equals(null)) {
//            workingDistrict = newState.movePrecinct(randomDistrict);
//        }
//        algorithmService.calculateObjectiveFunctions(randomDistrict);
//        algorithmService.calculateObjectiveFunctions(workingDistrict);
//        newState.setObjectiveMeasures();
//
//        oldState = algorithmService.getBetterState(oldState, newState, weights);

        return mv;
    }

    @RequestMapping(value = "/algorithm/proceed")
    @ResponseBody
    public ModelAndView algorithmProceed() {
        mv = new ModelAndView("index");


        return mv;
    }


}
