package com.expos.objects;

import com.expos.models.PrecinctpositionsEntity;
import com.expos.models.PrecinctsEntity;

import java.util.List;

public class Precinct {

    private String id;
    private String precinctName;
    private String stateName;
    private String districtName;
    private int year;
    private int population;
    private int republicans;
    private int democrats;
    private int other;
    private List<Precinct> adjacentPrecincts;
    private List<float[]> points;

    public Precinct(PrecinctsEntity precinctsEntity) {
        this.setPrecinctName(precinctsEntity.getPrecinctName());
        this.setStateName(precinctsEntity.getStateName());
        this.setDistrictName(precinctsEntity.getDistrictName());
        this.setYear(precinctsEntity.getYear());
        this.setPopulation(precinctsEntity.getPopulation());
        this.setRepublicans(precinctsEntity.getRepublicans());
        this.setDemocrats(precinctsEntity.getDemocrats());
        this.setOther(precinctsEntity.getOther());
    }

    public Precinct(Precinct precinct) {
        this.id = precinct.getId();
        this.precinctName = precinct.getPrecinctName();
        this.stateName = precinct.getStateName();
        this.districtName = precinct.getDistrictName();
        this.year = precinct.getYear();
        this.population = precinct.getPopulation();
        this.republicans = precinct.getRepublicans();
        this.democrats = precinct.getDemocrats();
        this.other = precinct.getOther();
        this.adjacentPrecincts = precinct.getAdjacentPrecincts();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrecinctName() {
        return precinctName;
    }

    public void setPrecinctName(String precinctName) {
        this.precinctName = precinctName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public int getRepublicans() {
        return republicans;
    }

    public void setRepublicans(int republicans) {
        this.republicans = republicans;
    }

    public int getDemocrats() {
        return democrats;
    }

    public void setDemocrats(int democrats) {
        this.democrats = democrats;
    }

    public int getOther() {
        return other;
    }

    public void setOther(int other) {
        this.other = other;
    }

    public List<Precinct> getAdjacentPrecincts() {
        return adjacentPrecincts;
    }

    public void setAdjacentPrecincts(List<Precinct> adjacentPrecincts) {
        this.adjacentPrecincts = adjacentPrecincts;
    }

    public List<float[]> getPoints() {
        return points;
    }

    public void setPoints(List<float[]> points) {
        this.points = points;
    }
}
