package com.expos.objects;

import com.expos.models.DistrictsEntity;

import java.util.List;

public class District {
    private String districtName;
    private String stateName;
    private int year;
    private int population;
    private int republicans;
    private int democrats;
    private int other;

    private List<Precinct> precincts;
    private List<Precinct> borderingPrecincts;

    private float compactness;
    private float equalPopulation;
    private float racialFairness;
    private float partisanFairness;
    private boolean contiguity;
    private boolean preservation;

    private float X[];
    private float Y[];

    public District(DistrictsEntity districtsEntity) {
        this.setStateName(districtsEntity.getStateName());
        this.setYear(districtsEntity.getYear());
        this.setDistrictName(districtsEntity.getDistrictName());
        this.setPopulation(districtsEntity.getPopulation());
        this.setRepublicans(districtsEntity.getRepublicans());
        this.setDemocrats(districtsEntity.getDemocrats());
        this.setOther(districtsEntity.getOther());
    }

    public District(District district) {
        this.districtName = district.getDistrictName();
        this.stateName = district.getStateName();
        this.year = district.getYear();
        this.population = district.getPopulation();
        this.republicans = district.getRepublicans();
        this.democrats = district.getDemocrats();
        this.other = district.getOther();
        this.precincts = district.getPrecincts();
        this.borderingPrecincts = district.getBorderingPrecincts();
        this.compactness = district.getCompactness();
        this.equalPopulation = district.getEqualPopulation();
        this.racialFairness = district.getRacialFairness();
        this.partisanFairness = district.getPartisanFairness();
        this.contiguity = district.isContiguity();
        this.preservation = district.isPreservation();
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public int getRepublicans() {
        return republicans;
    }

    public void setRepublicans(int republicans) {
        this.republicans = republicans;
    }

    public int getDemocrats() {
        return democrats;
    }

    public void setDemocrats(int democrats) {
        this.democrats = democrats;
    }

    public int getOther() {
        return other;
    }

    public void setOther(int other) {
        this.other = other;
    }

    public List<Precinct> getPrecincts() {
        return precincts;
    }

    public void setPrecincts(List<Precinct> precincts) {
        this.precincts = precincts;
    }

    public float getCompactness() {
        return compactness;
    }

    public void setCompactness(float compactness) {
        this.compactness = compactness;
    }

    public float getEqualPopulation() {
        return equalPopulation;
    }

    public void setEqualPopulation(float equalPopulation) {
        this.equalPopulation = equalPopulation;
    }

    public float getRacialFairness() {
        return racialFairness;
    }

    public void setRacialFairness(float racialFairness) {
        this.racialFairness = racialFairness;
    }

    public float getPartisanFairness() {
        return partisanFairness;
    }

    public void setPartisanFairness(float partisanFairness) {
        this.partisanFairness = partisanFairness;
    }

    public boolean isContiguity() {
        return contiguity;
    }

    public void setContiguity(boolean contiguity) {
        this.contiguity = contiguity;
    }

    public boolean isPreservation() {
        return preservation;
    }

    public void setPreservation(boolean preservation) {
        this.preservation = preservation;
    }

    public List<Precinct> getBorderingPrecincts() {
        return borderingPrecincts;
    }

    public void setBorderingPrecincts() {
        for (Precinct precinct : precincts) {
            if (calculateBordering(precinct))
                borderingPrecincts.add(precinct);
        }
    }

    public boolean calculateBordering(Precinct precinct) {
        return false;
    }

    public float getArea() {
        float area = 0;
        int j = getNumPoints() - 1;
        for (int i = 0; i < getNumPoints(); i++) {
            area = area + (getX()[j] + getX()[i]) * (Y[j] - Y[i]);
            j = i;
        }
        return area / 2;
    }

    public int getNumPoints() {
        int counter = 0;
        for (Precinct precinct : precincts) {
            counter += precinct.getPoints().size();
        }
        return counter;
    }

    public void loadXY() {
        int counter = 0;
        for (Precinct precinct : precincts) {
            for (float[] point : precinct.getPoints()) {
                X[counter] = point[0];
                Y[counter] = point[1];
                counter++;
            }
        }
    }

    public float[] getX() {
        return X;
    }

    public void setX(float[] x) {
        X = x;
    }

    public float[] getY() {
        return Y;
    }

    public void setY(float[] y) {
        Y = y;
    }


}
