package com.expos.objects;

import com.expos.models.StatesEntity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class State {
    private String stateName;
    private int year;
    private int population;
    private Integer republicans;
    private Integer democrats;
    private Integer other;

    private float compactness;
    private float equalPopulation;
    private float racialFairness;
    private float partisanFairness;
    private boolean contiguity;
    private boolean preservation;

    private List<District> districts;

    public State(State state) {
        this.stateName = state.getStateName();
        this.year = state.getYear();
        this.population = state.getPopulation();
        this.republicans = state.getRepublicans();
        this.democrats = state.getDemocrats();
        this.other = state.getOther();

        this.compactness = state.getCompactness();
        this.equalPopulation = state.getEqualPopulation();
        this.racialFairness = state.getRacialFairness();
        this.partisanFairness = state.getPartisanFairness();
        this.contiguity = state.isContiguity();
        this.preservation = state.isPreservation();
    }

    public State(StatesEntity statesEntity) {
        this.stateName = statesEntity.getStateName();
        this.year = statesEntity.getYear();
        this.population = statesEntity.getPopulation();
        this.republicans = statesEntity.getRepublicans();
        this.democrats = statesEntity.getDemocrats();
        this.other = statesEntity.getOther();
    }


    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public Integer getRepublicans() {
        return republicans;
    }

    public void setRepublicans(Integer republicans) {
        this.republicans = republicans;
    }

    public Integer getDemocrats() {
        return democrats;
    }

    public void setDemocrats(Integer democrats) {
        this.democrats = democrats;
    }

    public Integer getOther() {
        return other;
    }

    public void setOther(Integer other) {
        this.other = other;
    }

    public float getCompactness() {
        return compactness;
    }

    public void setCompactness(float compactness) {
        this.compactness = compactness;
    }

    public float getEqualPopulation() {
        return equalPopulation;
    }

    public void setEqualPopulation(float equalPopulation) {
        this.equalPopulation = equalPopulation;
    }

    public float getRacialFairness() {
        return racialFairness;
    }

    public void setRacialFairness(float racialFairness) {
        this.racialFairness = racialFairness;
    }

    public float getPartisanFairness() {
        return partisanFairness;
    }

    public void setPartisanFairness(float partisanFairness) {
        this.partisanFairness = partisanFairness;
    }

    public boolean isContiguity() {
        return contiguity;
    }

    public void setContiguity(boolean contiguity) {
        this.contiguity = contiguity;
    }

    public boolean isPreservation() {
        return preservation;
    }

    public void setPreservation(boolean preservation) {
        this.preservation = preservation;
    }

    public List<District> getDistricts() {
        return districts;
    }

    public void setDistricts(List<District> districts) {
        this.districts = districts;
    }

    public void processDistrictBorders() {
        for (District district : districts) {
            district.setBorderingPrecincts();
        }
    }

    public District getDistrict(String districtName) {
        for (District district : districts) {
            if (district.getDistrictName().equals(districtName)) {
                return district;
            }
        }
        return null;
    }

    public District getRandomDistrict() {
        int numDistricts = districts.size();
        Random random = new Random();
        int randomNum = random.nextInt((numDistricts-1)- 0);
        return districts.get(randomNum);
    }

    public District movePrecinct(District tryDistrict) {
        for (Precinct tryPrecinct : tryDistrict.getBorderingPrecincts()) {
            for (Iterator<Precinct> iter = tryPrecinct.getAdjacentPrecincts().listIterator(); iter.hasNext(); ) {
                Precinct adjacentPrecinct = iter.next();
                if (!(tryPrecinct.getDistrictName().equals(adjacentPrecinct.getDistrictName()))) {
                    District district = getDistrict(adjacentPrecinct.getDistrictName());
                    Precinct clonedPrecinct = new Precinct(tryPrecinct);
                    clonedPrecinct.setDistrictName(adjacentPrecinct.getDistrictName());
                    district.getPrecincts().add(clonedPrecinct);
                    tryDistrict.getPrecincts().remove(iter);
                    iter.remove();
                    return district;
                }
            }
        }
        return null;
    }

    public void resetObjectiveFunctions() {
        compactness = 0;
        equalPopulation = 0;
        racialFairness = 0;
        partisanFairness = 0;
        contiguity = true;
        preservation = true;
    }

    public void setObjectiveMeasures() {
        resetObjectiveFunctions();
        for (District district : districts) {
            compactness += district.getCompactness();
            equalPopulation += district.getEqualPopulation();
            racialFairness += district.getRacialFairness();
            partisanFairness += district.getPartisanFairness();
            contiguity = contiguity && district.isContiguity();
            preservation = preservation && district.isPreservation();
        }
    }

}
